package br.edu.unicid.bean;

import java.util.Date;

public class Aluno {
	private int caAluno ;
	private String nomeAluno ;
	private String emailAluno ;
	private Date dtaNasch ;
	private int idadeAluno ;
	private String endAluno;
	
	public int getCaAluno() {
		return caAluno;
	}
	public void setCaAluno(int caAluno) {
		this.caAluno = caAluno;
	}
	public Aluno(int caAluno, String nomeAluno, String emailAluno, Date dtaNasch, int idadeAluno, String endAluno) {
		super();
		this.caAluno = caAluno;
		this.nomeAluno = nomeAluno;
		this.emailAluno = emailAluno;
		this.dtaNasch = dtaNasch;
		this.idadeAluno = idadeAluno;
		this.endAluno = endAluno;
	}
	public String getNomeAluno() {
		return nomeAluno;
	}
	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}
	public String getEmailAluno() {
		return emailAluno;
	}
	public void setEmailAluno(String emailAluno) {
		this.emailAluno = emailAluno;
	}
	public Date getDtaNasch() {
		return dtaNasch;
	}
	public void setDtaNasch(Date dtaNasch) {
		this.dtaNasch = dtaNasch;
	}
	public int getIdadeAluno() {
		return idadeAluno;
	}
	public void setIdadeAluno(int idadeAluno) {
		this.idadeAluno = idadeAluno;
	}
	public String getEndAluno() {
		return endAluno;
	}
	public void setEdAluno(String edAluno) {
		this.endAluno = edAluno;
	}
	
}
